<?php

$mysql_conf = array(
    'host'    => 'localhost:3306',
    'db'      => 'tmsiwcom_flag',
    'db_user' => 'tmsiwcom_root',
    'db_pwd'  => 'kKgmWX8.^0Rc',
);

// 创建连接
$conn = mysqli_connect($mysql_conf['host'], $mysql_conf['db_user'], $mysql_conf['db_pwd'], $mysql_conf['db']);
// Check connection


$sql = "SELECT * FROM ip";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while ($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["id"] . " - Name: " . $row["TIME"] . " " . $row["ip"] . "<br>";
    }
} else {
    echo "0 结果";
}

mysqli_close($conn);
