<?php

$mysql_conf = array(
    'host'    => 'localhost:3306',
    'db'      => 'tmsiwcom_flag',
    'db_user' => 'tmsiwcom_root',
    'db_pwd'  => 'kKgmWX8.^0Rc',
);
function getip() {
    $unknown = 'unknown';
    $ip=NULL;
    if ( isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown) ) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif ( isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown) ) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    /*
    处理多层代理的情况
    或者使用正则方式：$ip = preg_match("/[\d\.]{7,15}/", $ip, $matches) ? $matches[0] : $unknown;
    */
    if (false !== strpos($ip, ','))
        $ip = reset(explode(',', $ip));
    return $ip;
};
function addMysql($mysqli,$ip){
    $dateS=date("Y-m-d H:i:s");
    return mysqli_query($mysqli,"insert into ip VALUES (0,'$dateS','$ip')");
}


function showImg($img)
{
    $info = getimagesize($img);
    $imgExt = image_type_to_extension($info[2], false);  //获取文件后缀
    $fun = "imagecreatefrom{$imgExt}";
    $imgInfo = $fun($img);                    //1.由文件或 URL 创建一个新图象。如:imagecreatefrompng ( string $filename )
//    $mime = $info['mime'];
    $mime = image_type_to_mime_type(exif_imagetype($img)); //获取图片的 MIME 类型
    header('Content-Type:' . $mime);
    $quality = 100;
    if ($imgExt == 'png') $quality = 9;        //输出质量,JPEG格式(0-100),PNG格式(0-9)
    $getImgInfo = "image{$imgExt}";
    $getImgInfo($imgInfo, null, $quality);    //2.将图像输出到浏览器或文件。如: imagepng ( resource $image )
    imagedestroy($imgInfo);
}

$ip=getip();
$mysqli = new mysqli($mysql_conf['host'], $mysql_conf['db_user'], $mysql_conf['db_pwd']);
mysqli_select_db( $mysqli, $mysql_conf['db'] );
addMysql($mysqli,$ip);
$mysqli->close();
showImg('./049.png');

