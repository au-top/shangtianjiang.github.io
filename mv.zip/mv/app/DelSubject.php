<?php


class DelSubject
{
    public function DelS(){
        $Error=[
           'ErrorList'=>[],
            'state'=>200
        ];
        empty($_GET['SId'])?$Error['ErrorList'][]='SId is NULL':NULL;
        empty($_GET['_token'])?$Error['ErrorList'][]='_token is NULL':NULL;
        if ( count($Error['ErrorList']) ){
            $Error['state']=-1;
            echo json_encode($Error);
            return 0;
        }
        $SId=(int)$_GET['SId'];
        $sql="delete from `subject` WHERE id=$SId ;";
        mysql_qi($sql);
        $Error['ErrorList'][]=$sql;
        echo json_encode($Error);
        return 0;
    }
}
