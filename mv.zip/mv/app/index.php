<?php


class index
{
    public function view(){
        require "./view/index.php";
    }
}
