<?php


class ShowSubject
{
    public function view(){
        $i=empty($_GET['mode'])?1:0;
        $classId=empty($_POST['typeselect'])?-1:$_POST['typeselect'];
        $sqlAdd='';
        if ($classId>-1){
            $sqlAdd='where `type`=';
            $sqlAdd.=$classId;
        };
           $all=$this->Show($i,$sqlAdd);
           $d=$all[0];
           $c=$all[1];
           $type=$i;
           $cd=$all[2];

        require './view/ShowSubject.php';
    }

    public function Show($i=1,$sqlAdd=''){
        $sql='select * from `class`';
        $cd=mysql_q($sql);
        $acd=[];
        if (!empty($cd)){
            for ($icd=0;$icd<count($cd);$icd++){
                $p=(string)$cd[$icd][0];
                $acd[$p]=$cd[$icd];
            }
        }
        if ($i) {
            //普通模式
            $sql = 'select * from subject '.$sqlAdd.' ;';
            $d = mysql_q($sql);
        }else{
            $sql='SELECT * from `subject` '.$sqlAdd.' ORDER BY error desc;';
            $d = mysql_q($sql);
        }

        return [$d,$acd,$cd];
    }

    public function VerIF(){
        // 1表示正确 0表示错误 -1表示异常
        $id=empty($_POST['id'])?NULL:$_POST['id'];
        $PostAn=empty($_POST['anV'])?NULL:$_POST['anV'];
        if($id!=NULL) {
            $s='';
            $sql = 'select * from `subject` where id=' . $id . ';';
            $an = (mysql_q($sql))[0][2];
            if ( empty( $an )){
                echo json_encode(['id'=>$id,'p'=>-2]);
            }
            if ($PostAn!=NULL&&$PostAn == $an) {
                $s=['id'=>$id,'p'=>1];
                $sql='update `subject` set `error`=`error`-1 where id='.$s['id'].' and `error`>0;';
                mysql_qi($sql);
            }else{
                $s=['id'=>$id,'p'=>0];
                $sql='update `subject` set `error`=`error`+1 where id='.$s['id'].';';
                mysql_qi($sql);
            }
        }else{
            $s=['id'=>$id,'p'=>-1];
        }
        echo json_encode($s);
    }
    public function s(){

    }
}
