<?php


class AddSubject
{
    //data processing
    private function addSFun($sd, $an, $type)
    {
        $sd .= $this->addImg($_FILES['ImgFile']??NULL);
        mysql_qi('INSERT INTO `subject` VALUES (0,\'' . $sd . '\',\'' . $an . '\',0,' . $type . '); ');
    }

    private function addTFun($d)
    {
        global $conn;
        mysql_qi('INSERT INTO `class` VALUES (0,\'' . $d . '\'); ');
        return mysqli_insert_id($conn);//获取插入的id
    }


    // data stream
    public function view()
    {
        $d = mysql_q('select * from `class`');
        $td = mysql_q('SELECT * FROM `subject` ORDER BY id DESC LIMIT 0,1');
        require "./view/addSubject.php";
    }

    public function addS()
    {
        $sd = (string)$_POST['SubjectData'];
        $an = (string)$_POST['Answer'];
        $type = (int)$_POST['type'];
        $this->addSFun($sd, $an, $type);
        redirect('AddSubject', 'view');
    }

    public function addT()
    {
        $d = $_GET['data'];
        $this->addTFun($d);

    }

    public function addImg($fimg = null)
    {
        $s = '';
        if ($fimg != null && $fimg['error'] == 0) {
            $FileName = time() . rand(1, 100) . '.png';
            move_uploaded_file($fimg['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . '/File/' . $FileName);
            $s = '<img src="' . './File/' . $FileName . '"/>';
        }
        return $s;
    }

    public function addFileAnalysis()
    {
        $JsonFileURL = $_FILES['JsonFile']['tmp_name'];
        $data = json_decode(file_get_contents($JsonFileURL));
        for ($i = 0; $i < count($data); $i++) {
            $className = $data[$i]->ClassName;
            $classId = $this->addTFun($className);
            for ($ii = 0; $ii < count($data[$i]->subjectInfoArr); $ii++) {
                $Subject = $data[$i]->subjectInfoArr[$ii]->SU;
                $An = $data[$i]->subjectInfoArr[$ii]->AN;
                $this->addSFun($Subject, $An, $classId);
            }
        }
//        redirect('AddSubject', 'view');
    }
}


