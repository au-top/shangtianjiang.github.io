<?php
define('app', './app/');
$conn=null;//mysql

$localhost = "127.0.0.1";
$userName = "root";
$password = "Mww123";
$database = "Mwdata";
$conn=mysqli_connect($localhost, $userName, $password, $database);
if (!$conn){
    echo('mysql link error ' . mysqli_connect_error());
}
mysqli_query($conn, "set name utf8");
session_start();//开启session
require './functions.php';
global $token;
if (empty($_SESSION['token'])) {
    $_SESSION['token'] = md5(mt_rand(0, 100) . mt_rand(0, 100) . mt_rand(0, 100));
}
$token=$_SESSION['token'];
$a = isset($_GET['a']) ? $_GET['a'] : null;
$p = isset($_GET['p']) ? $_GET['p'] : null;
if ($a != null && $p != null) {
    $appClassFileUrl = app . $a . '.php';
    require $appClassFileUrl;
    $app = new $a;
    $app->$p();
}else{
    require './app/index.php';
    $app=new index();
    $app->view();
}
