<?php
function mysql_q($sql){
    global $conn;
    return mysqli_query($conn, $sql)->fetch_all();
}
function mysql_qi($sql){
    global $conn;
    return mysqli_query($conn, $sql);
}
function redirect($app,$p){
    header('location:http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.'a='.$app.'&p='.$p);
}
