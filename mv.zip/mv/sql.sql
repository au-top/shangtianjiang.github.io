CREATE TABLE subject (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY not null,
    dm MEDIUMTEXT NOT NULL,
    da MEDIUMTEXT NOT NULL,
    error int not null,
    type int NOT NULL
);
CREATE TABLE class (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY not null,
    name varchar(30) not null
);
