<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="jq.js"></script>
    <link rel="stylesheet" href="./css/as.css">
</head>
<body>
<div class="c">
    <form method="post"  enctype="multipart/form-data"  action="./?a=AddSubject&p=addS">
    <h1>Add Subject</h1>
    <div class="d">
        <span class="stand">SubjectData:</span>
        <textarea required="required" name="SubjectData" style="width: 100%;height: 150px"></textarea>
    </div>
    <div class="d">
        <span class="stand">Answer</span>
        <input required="required" name="Answer" type="text">
    </div>
    <div class="d">
        <span  class="stand">Type</span>
        <input required="required" name="type" type="number">
    </div>
      <div class="ImgFileList">
            <span>ImgFile: </span>
            <input name="ImgFile" type="file">
        </div>   
 <button style="display: block;width: 80%;height: 30px;margin: 0 auto;">post</button>
    </form>
<div>
    <div class="ShowEnd">
        <div>id=</div>  <?php echo empty( $td[0][0])?'NULL':$td[0][0] ?><br/>
        <div>dm= </div> <?php echo empty( $td[0][1])?'NULL':$td[0][1] ?><br/>
        <div>da= </div> <?php echo  empty( $td[0][2])?'NULL':$td[0][2] ?><br/>
        <div>type= </div> <?php echo  empty( $td[0][4])?'NULL':$td[0][4] ?><br/>

    </div>

</div>
</div>
<div class="c">
    <h1>Add Type</h1>
    <form method="get" action="./?">
    <div class="d">

            <span class="stand">Type</span>
            <input name="data" id="TypeInput" required="required" type="text">
            <input name="p" required="required" type="hidden" value="addT">
            <input name="a"  required="required" type="hidden" value="AddSubject">

    </div>
     <button style="display: block;width: 80%;height: 30px;margin: 0 auto;">post</button>
    </form>

    <div class="Classul">
    <?php
    echo "<div> <div><span>ID</span><span>TypeName</span></div>";
    for ($i=0;$i<count($d);$i++){

        echo "<div><span>";
         print_r($d[$i][0]);
         echo "</span><span>";
         print_r($d[$i][1]);
         echo "</span></div>";
    }
    echo "</div>";
?></div>

</div>
<script>

</script>
</body>
</html>
