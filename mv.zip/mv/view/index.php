<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./jq.js"></script>
    <link rel="stylesheet" href="./css/index.css">
</head>
<body>
<div class="d">
    <a href="?a=ShowSubject&p=view">Subject</a>
</div>
<div class="d">
    <a href="?a=AddSubject&p=view">AddSubject</a>
</div>

</body>
</html>
