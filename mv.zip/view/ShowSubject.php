<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="./css/showS.css">
    <script src="jq.js"></script>
</head>
<body>
<div class="TopShow">
    <?php if ($type){?>
        <form method="post" action="./?a=ShowSubject&p=view&mode=1">
        <button id="Select">Error mode</button>
            <div class="c">
                <select name="typeselect">
                    <option value="-1">*</option>
                    <?php for ($i=0;$i<count($cd);$i++){ ?>
                        <option <?php echo $cd[$i][0]==$classId?"selected = \"selected\"":'';?> value="<?=$cd[$i][0]?>"><?=$cd[$i][1]?></option>
                    <?php }?>
                </select>

            </div>
        </form>
        <div class="c">
            Search for this class in this pattern
        </div>
        <form method="post" action="./?a=ShowSubject&p=view">
            <div class="c">
                <select name="typeselect">
                    <option value="-1">*</option>
                    <?php for ($i=0;$i<count($cd);$i++){ ?>
                        <option <?php echo $cd[$i][0]==$classId?"selected = \"selected\"":'';?> value="<?=$cd[$i][0]?>"><?=$cd[$i][1]?></option>
                    <?php }?>
                </select>
                <button style="float: right"> SELECT </button>
            </div>
        </form>
        <div class="c">
            <span> this is a ordinary mode </span>
        </div>
    <?php }else{ ?>
        <form method="post" action="./?a=ShowSubject&p=view">
            <button id="Select">Error mode</button>
            <div class="c">
                <select name="typeselect">
                    <option value="-1">*</option>
                    <?php for ($i=0;$i<count($cd);$i++){ ?>
                        <option <?php echo $cd[$i][0]==$classId?"selected = \"selected\"":'';?> value="<?=$cd[$i][0]?>"><?=$cd[$i][1]?></option>
                    <?php }?>
                </select>
            </div>
        </form>
        <div class="c">
            Search for this class in this pattern
        </div>
        <form method="post" action="./?a=ShowSubject&p=view&mode=1">
            <div class="c">
                <select name="typeselect">
                    <option value="-1">*</option>
                    <?php for ($i=0;$i<count($cd);$i++){ ?>
                        <option <?php echo $cd[$i][0]==$classId?"selected = \"selected\"":'';?> value="<?=$cd[$i][0]?>"><?=$cd[$i][1]?></option>
                    <?php }?>
                </select>
                <button style="float: right"> SELECT </button>
            </div>
        </form>

        <div class="c">
            <span> this is a error mode </span>
        </div>
    <?php }?>
</div>
    <div class="c SJDataBox">
<?php for ($i=0;$i<count($d);$i++){ ?>
        <div class="SJData">
            <div class="LabelTEXT" data-id="<?=$d[$i][0]?>"></div>
            <div>
                <div> Class: <?php print_r( $c[$d[$i][0]][1] )?></div>
                <span class="Sid" id="Sid<?=$d[$i][0]?>">
                    <?=$i+1?>.
                </span>
                <span>
                  <?=$d[$i][1]?>
                </span>
                <span class="errorNum">
                    Error Num: <span id="errorNum<?=$d[$i][0]?>"><?=$d[$i][3]?></span>
                </span>
            </div>
            <div class="AnBox">
                <input type="text" id="An<?=$d[$i][0]?>" placeholder="Answer" >
            </div>
            <div class="AnInfo">
                <span id="SidAnInfo<?=$d[$i][0]?>"></span>
                <button id="Bu<?=$d[$i][0]?>" onclick="verif(<?=$d[$i][0]?>)" class="Verif">Verif</button>
            </div>
            <div class="dc">
            </div>
        </div>
<?php }?>
        <button onclick="ALLVerif()" class="ButAll">ALLPOST</button>
    </div>

</body>
<script>
    function ALLVerif() {
        var arr=$('.LabelTEXT');
        for (let i=0;i<arr.length;i++) {
           verif($(arr[i]).data('id'));
        }
    }
    function verif(id) {
        $.ajax({
         url:'./?a=ShowSubject&p=VerIF',
            type:'post',
            data: {
                'id':id,
                'anV':$('#An'+id).val()
            },
            success:function (e) {
             e=JSON.parse(e);
             console.log(e);
             let obj=$('#SidAnInfo'+e.id);
             let objNum=$('#errorNum'+e.id);
             switch (e.p) {
                 case 1:{
                     obj.css('color','#05ba00');
                     obj[0].innerHTML='Correct';
                     if ( Number(objNum[0].innerHTML>0) ) {
                         objNum[0].innerHTML = Number(objNum[0].innerHTML) - 1;
                     }
                 }break;
                 case 0:{
                     obj.css('color','red');
                     obj[0].innerHTML='Wrong answer';
                     objNum[0].innerHTML = Number(objNum[0].innerHTML) +1;
                 }break;
                 default:{
                     obj.css('color','red');
                     obj[0].innerHTML='ERROR '.e.p;
                 }
             }
            }
        })
    }
</script>
</html>
